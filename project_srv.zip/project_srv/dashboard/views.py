from django.shortcuts import render
from django.core.paginator import Paginator
from django.contrib.auth.decorators import login_required
from company.models import Tank, Site, Company, Nozzle, Pump
from users.models import Account
from . forms import GeneratePumpReportForm, GenerateTankReportForm
from datetime import datetime

from django.db.models import Sum
from django.http import JsonResponse

# DataBase Links

import requests
from requests.auth import HTTPBasicAuth

# Create your views here.

def saleshistory(value, file_name):
	arr = []

	with open(f'dashboard/files/{file_name}', 'r') as myfile:
		for line in myfile:
			arr.append(float(line))

	arr.pop(0)
	arr.append(round(value))
	print('Debug')
	print(arr)

	with open(f'dashboard/files/{file_name}', 'w') as newfile:
		for line in arr:
			newfile.write(str(line) + '\n')

	return arr


def sales_labels(value, file_name):
	arr = []

	with open(f'dashboard/files/{file_name}', 'r') as myfile:
		for line in myfile:
			arr.append(int(line))

	arr.pop(0)
	arr.append(round(value))
	print('Debug')
	print(arr)

	with open(f'dashboard/files/{file_name}', 'w') as newfile:
		for line in arr:
			newfile.write(str(line) + '\n')

	return arr


@login_required
def dashboard(request):

	url = 'http://api.ashberry.uk:5099/tanksstatus'
	response = requests.get(url, auth=HTTPBasicAuth('ashberry', 'Ashberry1000*'))
	test_data = response.json()

	account = request.user

	# User Dashboard


	if request.user.is_admin:
		obj = Company.objects.all()

		context = {
			'obj': obj
		}

		return render(request, 'company/dashboard.html', context)

	else:
		try:
			url = 'http://api.ashberry.uk:5099/tanksstatus'
			response = requests.get(url, auth=HTTPBasicAuth('ashberry', 'Ashberry1000*'))
			data = response.json()

			for object in data:
				print(object['Product'])

			context = {
				'obj': data,
			}

		except:
			context = {}


		return render(request, 'dashboard/dashboard.html', context)


@login_required
def pumps(request):

	pump = Pump.objects.filter(account = request.user)

	context = {
		'pump': pump,
	}

	return render(request, 'dashboard/pumps.html', context)


@login_required
def tanks(request):

	account = request.user

	company = Company.objects.get(account = account)

	site = Site.objects.filter(company = company)

	# Calculating Total for the company.

	hsd_tank_filling = 0
	pmg_tank_filling = 0
	hobc_tank_filling = 0

	for obj in site:
		for tank in obj.tank.all():
			if tank.fuel_grade == 'HSD':
				hsd_tank_filling += tank.tank_filling
				print('hsd tank_filling: {}'.format(hsd_tank_filling))

			if tank.fuel_grade == 'PMG':
				pmg_tank_filling += tank.tank_filling
				print('pmg tank_filling: {}'.format(pmg_tank_filling))

			if tank.fuel_grade == 'HOBC':
				hobc_tank_filling += tank.tank_filling
				print('hobc tank_filling: {}'.format(hobc_tank_filling))

	for comp_tank in company.tank.all():
		if comp_tank.fuel_grade == 'HSD':
			comp_tank.tank_filling = hsd_tank_filling

		elif comp_tank.fuel_grade == 'PMG':
			comp_tank.tank_filling = pmg_tank_filling

		elif comp_tank.fuel_grade == 'HOBC':
			comp_tank.tank_filling = hobc_tank_filling
		
		comp_tank.save()

	obj = Tank.objects.filter(status='Online')
	# obj = Tank.objects.all().exculde(status = 'Company')

	context = {
		'company': company,
		'site': site,
		'obj': obj,
	}

	return render(request, 'dashboard/tanks.html', context)


@login_required
def pump_report(request):

	data = ''
	start_date = ''
	end_date = ''

	if request.method == 'POST':
		form = GeneratePumpReportForm(request.POST)

		if form.is_valid():
			start_date = form.cleaned_data.get('start_date')
			end_date = form.cleaned_data.get('end_date')

			# print(f'{start_date} {end_date}')
			start_date = str(start_date).replace(' ', 'T')
			start_date = start_date.replace('+00:00', '')

			end_date = str(end_date).replace(' ', 'T')
			end_date = end_date.replace('+00:00', '')

			# url = "http://125.209.92.237:5099/nozzle?startDate=2020-09-01T00:00:00&endDate=2020-09-30T23:00:00"
			url = "http://125.209.92.237:5099/nozzle?startDate="+start_date+"&endDate="+end_date+""

			response = requests.post(url, auth=HTTPBasicAuth('admin', 'admin'))
			
			data = response.json()
			print(data)

		else:
			print(form.errors)

	else:
		form = GeneratePumpReportForm(initial = {
				'start_date': datetime.now(),
				'end_date': datetime.now(),
			})

	
	context = {
		'start_date': start_date,
		'end_date': end_date,
		'form': form,
		'data': data,
	}

	return render(request, 'dashboard/pump_report.html', context)


@login_required
def tank_report(request):

	data = ''
	start_date = ''
	end_date = ''

	if request.method == 'POST':
		form = GenerateTankReportForm(request.POST)

		if form.is_valid():
			start_date = form.cleaned_data.get('start_date')
			end_date = form.cleaned_data.get('end_date')

			# print(f'{start_date} {end_date}')
			start_date = str(start_date).replace(' ', 'T')
			start_date = start_date.replace('+00:00', '')

			end_date = str(end_date).replace(' ', 'T')
			end_date = end_date.replace('+00:00', '')

			url = "http://125.209.92.237:5099/tanks?startDate="+start_date+"&endDate="+end_date+""

			response = requests.post(url, auth=HTTPBasicAuth('admin', 'admin'))

			data = response.json()
			print(data)

		else:
			print(form.errors)

	else:
		form = GenerateTankReportForm(initial = {
				'start_date': datetime.now(),
				'end_date': datetime.now(),
			})

	context = {
		'start_date': start_date,
		'end_date': end_date,
		'form': form,
		'data': data,
	}

	return render(request, 'dashboard/tank_report.html', context)


@login_required
def pmg_sales_chart(request):

	labels = []
	data = []
	currentvalue = ''

	currentdatetime = datetime.now()

	currentdatetime = str(currentdatetime).replace(' ', 'T')
	currentdatetime = currentdatetime.replace('+00:00', '')
	currentdatetime = currentdatetime.split('.')
	currentdatetime = currentdatetime[0]

	label_time = currentdatetime[11:13]

	# Changing Label with time

	label_time = int(label_time)

	temp_labels = sales_labels(label_time, 'pmg_labels.txt')

	for i in temp_labels:
		if i < 12:
			if i == 0:
				i = '12am'
			else:
				i = f'{i}am'
		else:
			if i == 12:
				i = '12pm'
			else:
				i = f'{i - 12}pm'

		labels.append(i)

	print(labels)

	# Sales Data from api.

	url = "http://api.ashberry.uk:5099/salesstatus?currentDateTime="+currentdatetime+""
	response = requests.get(url, auth=HTTPBasicAuth('ashberry', 'Ashberry1000*'))
	currentsale = response.json()
	print(currentsale)
	for object in currentsale:
		if object['Product'] == 'PMG':
			currentvalue = object['Amount']

	print(currentvalue)

	data = saleshistory(currentvalue, 'pmg_sales.txt')

	return JsonResponse(data={
		'labels': labels,
		'data': data,
	})


@login_required
def hsd_sales_chart(request):

	labels = []
	data = []
	currentvalue = ''

	currentdatetime = datetime.now()

	currentdatetime = str(currentdatetime).replace(' ', 'T')
	currentdatetime = currentdatetime.replace('+00:00', '')
	currentdatetime = currentdatetime.split('.')
	currentdatetime = currentdatetime[0]

	label_time = currentdatetime[11:13]

	# Changing Label with time

	label_time = int(label_time)

	temp_labels = sales_labels(label_time, 'hsd_labels.txt')

	for i in temp_labels:
		if i < 12:
			if i == 0:
				i = '12am'
			else:
				i = f'{i}am'
		else:
			if i == 12:
				i = '12pm'
			else:
				i = f'{i - 12}pm'

		labels.append(i)

	print(labels)

	# Sales Data from api.

	url = "http://api.ashberry.uk:5099/salesstatus?currentDateTime="+currentdatetime+""
	response = requests.get(url, auth=HTTPBasicAuth('ashberry', 'Ashberry1000*'))
	currentsale = response.json()
	for object in currentsale:
		if object['Product'] == 'HSD':
			currentvalue = object['Amount']

	print(currentvalue)

	data = saleshistory(currentvalue, 'hsd_sales.txt')

	return JsonResponse(data={
		'labels': labels,
		'data': data,
	})


@login_required
def hobc_sales_chart(request):
	
	labels = []
	data = []

	currentvalue = ''

	currentdatetime = datetime.now()

	currentdatetime = str(currentdatetime).replace(' ', 'T')
	currentdatetime = currentdatetime.replace('+00:00', '')
	currentdatetime = currentdatetime.split('.')
	currentdatetime = currentdatetime[0]

	label_time = currentdatetime[11:13]

	# Changing Label with time

	label_time = int(label_time)

	temp_labels = sales_labels(label_time, 'hobc_labels.txt')

	for i in temp_labels:
		if i < 12:
			if i == 0:
				i = '12am'
			else:
				i = f'{i}am'
		else:
			if i == 12:
				i = '12pm'
			else:
				i = f'{i - 12}pm'

		labels.append(i)

	print(labels)

	# Sales Data from api.

	url = "http://api.ashberry.uk:5099/salesstatus?currentDateTime="+currentdatetime+""
	response = requests.get(url, auth=HTTPBasicAuth('ashberry', 'Ashberry1000*'))
	currentsale = response.json()
	for object in currentsale:
		if object['Product'] == 'HOBC':
			currentvalue = object['Amount']

	print(currentvalue)

	data = saleshistory(currentvalue, 'hobc_sales.txt')

	return JsonResponse(data={
		'labels': labels,
		'data': data,
	})


@login_required
def tank_chart(request):
	total_volume = 0
	labels = []
	data = []

	obj = Pump.objects.filter(account = request.user)
	for pump in obj:
		labels.append(pump.name)
		for nozzle in pump.nozzle.all():
			total_volume += nozzle.total_amount

		data.append(total_volume)
		total_volume = 0

	return JsonResponse(data={
		'labels': labels,
		'data': data,
	})
