from django import forms
from company.models import Pump

class GeneratePumpReportForm(forms.Form):

	start_date = forms.DateTimeField()
	end_date = forms.DateTimeField()


class GenerateTankReportForm(forms.Form):

	start_date = forms.DateTimeField()
	end_date = forms.DateTimeField()
