from django import forms
from .models import Company, Site, Tank, Pump, Nozzle

class CompanyRegisterationForm(forms.ModelForm):

	class Meta:
		model = Company
		fields = [
			'account',
			'tank',
			'company_name',
			'business_type',
			'contact_number',
			'email',
			'address',
			'no_of_sites',
		]


class SiteRegisterationForm(forms.ModelForm):

	class Meta:
		model = Site
		fields = [
			'company',
			'rd_number',
			'site_name',
			'rd_status',
			'supply_point',
			'dealer_name',
			'dealer_contact',
			'site_address',
			'district',
			'tehsil',
			'latitude',
			'longitude',
			'zone',
			'region',
			'zone_manager',
			'region_manager',
			'dispenser',
			'nozzels',
			'atg',
		]


class AddTankForm(forms.ModelForm):

	class Meta:
		model = Tank
		fields = [
			'status',
			'fuel_grade',
			'tank_filling',
			'product_mm',
			'water_mm',
			'temperature',
			'product_l',
			'water_l',
			'ullage',
			'tc_volume',
			'dencity',
			'mass',
		]


class PumpRegisterationForm(forms.ModelForm):

	class Meta:
		model = Pump
		fields = [
			'name',
			'account',
			'request',
		]	
