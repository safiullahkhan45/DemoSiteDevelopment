from django.shortcuts import render, redirect
from django.core.paginator import Paginator
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.contrib.admin.views.decorators import staff_member_required
from .models import Company, Site, Tank
from . forms import CompanyRegisterationForm, SiteRegisterationForm, AddTankForm, PumpRegisterationForm

# Create your views here.

@staff_member_required
def companies(request):

	obj = Company.objects.all()

	context = {
		'obj': obj
	}

	return render(request, 'company/companies.html', context)


@staff_member_required
def sites(request, id):

	company = Company.objects.get(pk=id)

	obj = Site.objects.filter(company = company)

	if company.no_of_sites == 0:
		context = {
			'Empty': True,
			'company': company
		}

	else:
		context = {
			'obj': obj,
			'company': company
		}

	return render(request, 'company/sites.html', context)


@staff_member_required
def site_details(request, id):

	site = Site.objects.get(pk=id)
	company = Company.objects.get(pk = site.company.id)

	context = {
		'site': site,
		'company': company
	}

	return render(request, 'company/site_details.html', context)


@staff_member_required
def company_registeration(request):

	if request.method == 'POST':
		form = CompanyRegisterationForm(request.POST)
		if form.is_valid():
			form.save()
			messages.success(request, 'Company added successfuly !!')
			return redirect('dashboard')

		else:
			# messages.error(request, 'Form Error !!')
			print(form.errors)

	else:
		form = CompanyRegisterationForm()

	context = {
		'form': form
	}

	return render(request, 'company/company_registeration.html', context)


@staff_member_required
def site_registeration(request):
	
	if request.method == 'POST':
		form = SiteRegisterationForm(request.POST)
		if form.is_valid():
			company = form.cleaned_data.get('company')
			comp_obj = Company.objects.get(company_name = company)
			comp_obj.no_of_sites += 1
			comp_obj.save()
			form.save()
			messages.success(request, 'Site added successfuly !!')
			return redirect('companies')

		else:
			messages.error(request, 'Form Error !!')

	else:
		form = SiteRegisterationForm()

	context = {
		'form': form
	}

	return render(request, 'company/site_registeration.html', context)


@staff_member_required
def add_company_tank(request, id):

	company = Company.objects.get(pk=id)

	if request.method == 'POST':
		form = AddTankForm(request.POST)
		if form.is_valid():
			new_tank = form.save()
			company.tank.add(new_tank)
			messages.success(request, 'tank added successfuly !!')
			return redirect('companies')

		else:
			messages.error(request, 'Form Error !!')

	else:
		form = AddTankForm()

	context = {
		'form': form
	}

	return render(request, 'company/add_tank.html', context)


@staff_member_required
def add_site_tank(request, id):

	site = Site.objects.get(pk=id)

	company = Company.objects.get(pk=site.company.id)

	if request.method == 'POST':
		form = AddTankForm(request.POST)
		if form.is_valid():
			status = form.cleaned_data.get('status')
			fuel_grade = form.cleaned_data.get('fuel_grade')
			tank_filling = form.cleaned_data.get('tank_filling')
			product_mm = form.cleaned_data.get('product_mm')
			water_mm = form.cleaned_data.get('water_mm')
			temperature = form.cleaned_data.get('temperature')
			product_l = form.cleaned_data.get('product_l')
			water_l = form.cleaned_data.get('water_l')
			ullage = form.cleaned_data.get('ullage')
			tc_volume = form.cleaned_data.get('tc_volume')
			dencity = form.cleaned_data.get('dencity')
			mass = form.cleaned_data.get('mass')

			site_array = site.tank.all()
			site_has_tank = False

			for tank in site_array:
				if tank.fuel_grade == fuel_grade:
					site_has_tank = True

			if site_has_tank == False:
				new_tank = form.save()
				site.tank.add(new_tank)


				# Adding the same tank to company if the company hasn't added the tank yet.

				
				company_array = company.tank.all()
				company_has_tank = False

				for tank in company_array:
					if tank.fuel_grade == fuel_grade:
						company_has_tank = True

				if company_has_tank == False:
					comp_tank = Tank(
						status = 'Company',
						fuel_grade = fuel_grade,
						tank_filling = tank_filling,
						product_mm = product_mm,
						water_mm = water_mm,
						temperature = temperature,
						product_l = product_l,
						water_l = water_l,
						ullage = ullage,
						tc_volume = tc_volume,
						dencity = dencity,
						mass = mass,
					)

					comp_tank.save()

					company.tank.add(comp_tank)		
				
				messages.success(request, 'tank added successfuly !!')
				return redirect('companies')

			else:
				messages.error(request, 'tank already registered on site.')

		else:
			messages.error(request, 'Form Error !!')

	else:
		form = AddTankForm()

	context = {
		'form': form
	}

	return render(request, 'company/add_site_tank.html', context)


@staff_member_required
def company_tanks(request, id):

	company = Company.objects.get(pk=id)
	site = Site.objects.filter(company = company)

	# Calculating Total for the company.

	hsd_volume = 0
	pmg_volume = 0
	hobc_volume = 0

	for obj in site:
		for tank in obj.tank.all():
			if tank.tank_filling == 'HSD':
				hsd_volume += tank.volume
				print('hsd volume: {}'.format(hsd_volume))

			if tank.tank_filling == 'PMG':
				pmg_volume += tank.volume
				print('pmg volume: {}'.format(pmg_volume))

			if tank.tank_filling == 'HOBC':
				hobc_volume += tank.volume
				print('hobc volume: {}'.format(hobc_volume))

	for comp_tank in company.tank.all():
		if comp_tank.tank_filling == 'HSD':
			comp_tank.volume = hsd_volume

		elif comp_tank.tank_filling == 'PMG':
			comp_tank.volume = pmg_volume

		elif comp_tank.tank_filling == 'HOBC':
			comp_tank.volume = hobc_volume
		
		comp_tank.save()

	context = {
		'company': company,
		'site': site
	}
	
	return render(request, 'company/company_tanks.html', context)


@staff_member_required
def site_tanks(request, id):

	site = Site.objects.get(pk=id)

	context = {
		'site': site
	}
	
	return render(request, 'company/site_tanks.html', context)


@staff_member_required
def pump_registeration(request):
	
	if request.method == 'POST':
		form = PumpRegisterationForm(request.POST)
		if form.is_valid():
			form.save()
			messages.success(request, 'Pump added successfuly !!')
			return redirect('dashboard')

		else:
			messages.error(request, 'Form Error !!')

	else:
		form = PumpRegisterationForm()

	context = {
		'form': form
	}

	return render(request, 'company/pump_registeration.html', context)


@staff_member_required
def delete_company(request, id):

	obj = Company.objects.get(pk=id)
	obj.delete()

	return redirect('dashboard')


@staff_member_required
def edit_company(request, id):

	if request.method == "GET":
		obj = Company.objects.get(pk=id)
		form = CompanyRegisterationForm(instance = obj)

		context = {
			'form': form
		}

		return render(request, 'company/edit_company.html', context)

	else:
		obj = Company.objects.get(pk=id)
		form = CompanyRegisterationForm(request.POST, instance = obj)
		if form.is_valid():
			form.save()

		return redirect('dashboard')

