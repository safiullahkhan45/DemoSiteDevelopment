from django.urls import path
from . import views as comp_views

urlpatterns = [
    path('sites/<int:id>/', comp_views.sites, name='sites'),
    path('site_tanks/<int:id>/', comp_views.site_tanks, name='site_tanks'),

    # Company Urls

    path('company_registeration', comp_views.company_registeration, name='company_registeration'),
    path('add_company_tank/<int:id>', comp_views.add_company_tank, name='add_company_tank'),
    path('company_tanks/<int:id>/', comp_views.company_tanks, name='company_tanks'),
    path('companies', comp_views.companies, name='companies'),
    path('delete_company/<int:id>', comp_views.delete_company, name='delete_company'),
    path('edit_company/<int:id>', comp_views.edit_company, name='edit_company'),

    # Site Urls

    path('site_registeration', comp_views.site_registeration, name='site_registeration'),
    path('site_details/<int:id>', comp_views.site_details, name='site_details'),
    path('add_site_tank/<int:id>', comp_views.add_site_tank, name='add_site_tank'),

    # Pump Urls

    path('pump_registeration', comp_views.pump_registeration, name='pump_registeration'),
    # path('company_pumps/<int:id>/', comp_views.company_pumps, name='company_pumps'),
]