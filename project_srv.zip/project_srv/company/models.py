from django.db import models
from users.models import Account

# Create your models here.


class Tank(models.Model):

	tank_choices = [
		('PMG', 'PMG'),
		('HSD', 'HSD'),
		('HOBC', 'HOBC'),
	]

	status_choices = [
		('Online', 'Online'),
		('Offline', 'Offline'),
		('Company', 'Company'),
	]

	zero = 0.0

	status = models.CharField(max_length=30, choices=status_choices, default='Online')
	fuel_grade = models.CharField(max_length=4, choices=tank_choices)
	tank_filling = models.FloatField(default=zero)
	product_mm = models.FloatField(default=zero)
	water_mm = models.FloatField(default=zero)
	temperature = models.FloatField(default=zero)
	product_l = models.FloatField(default=zero)
	water_l = models.FloatField(default=zero)
	ullage = models.FloatField(default=zero)
	tc_volume = models.FloatField(default=zero)
	dencity = models.FloatField(default=zero)
	mass = models.FloatField(default=zero)


	def __str__(self):
		return self.fuel_grade


class Company(models.Model):
	
	account =  models.OneToOneField(Account, on_delete=models.CASCADE)
	tank = models.ManyToManyField(Tank, null=True, blank=True)
	company_name = models.CharField(max_length=30)
	business_type = models.CharField(max_length=30)
	contact_number = models.CharField(max_length=30)
	email = models.EmailField()
	address = models.CharField(max_length=200)
	no_of_sites = models.IntegerField(default=0, null=True, blank=True)

	def __str__(self):
		return self.company_name


	class Meta:

		verbose_name_plural = 'Companies'


class Site(models.Model):

	rd_status_choices = [
		('K-Form', 'K-Form'),
		('Non K-Form', 'Non K-Form'),
		('K-Form Cancellation in progress', 'K-Form Cancellation in progress'),
		('K-Form Canceled', 'K-Form Canceled'),
		('Others', 'Others'),
	]

	tank = models.ManyToManyField(Tank, null=True, blank=True)
	company = models.ForeignKey(Company, on_delete=models.CASCADE)
	# General Info
	rd_number = models.IntegerField()
	site_name = models.CharField(max_length=30)
	rd_status = models.CharField(max_length=40, choices=rd_status_choices, default='K-Form')
	supply_point = models.CharField(max_length=30, null=True)
	# Contact
	dealer_name = models.CharField(max_length=30)
	dealer_contact = models.CharField(max_length=30)
	site_address = models.CharField(max_length=200)
	district = models.CharField(max_length=30)
	tehsil = models.CharField(max_length=30)
	# Coordinates
	latitude = models.FloatField()
	longitude = models.FloatField()
	# Area
	zone = models.CharField(max_length=30)
	region = models.CharField(max_length=30)
	zone_manager = models.CharField(max_length=30)
	region_manager = models.CharField(max_length=30)
	# Content
	dispenser = models.IntegerField()
	nozzels = models.IntegerField()
	atg = models.BooleanField(default=True)


	def __str__(self):
		return self.site_name


class Nozzle(models.Model):

	zero = 0.0

	status = models.CharField(max_length=120)
	price = models.FloatField(default=zero)
	filled_volume = models.FloatField(default=zero)
	filled_amount = models.FloatField(default=zero)
	total_volume = models.FloatField(default=zero)
	total_amount = models.FloatField(default=zero)

	def __str__(self):
		return str(self.id)


class Pump(models.Model):

	name = models.CharField(max_length=120)
	account = models.ForeignKey(Account, on_delete=models.CASCADE)
	nozzle = models.ManyToManyField(Nozzle, null=True, blank=True)
	request = models.CharField(max_length=120, blank=True, null=True)

	def __str__(self):
		return f'{self.name} - {self.account}'
